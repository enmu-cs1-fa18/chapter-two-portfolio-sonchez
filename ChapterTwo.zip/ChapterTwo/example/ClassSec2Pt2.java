

public class ClassSec2Pt2 {

	public static void main(String[] args) {
		// Arithmetic part 2: Powers and Roots, Floating point to Int
		// Square root
		// Math.sqrt(arg0); // arg0 is the 
		// Exponent (power)
		// Math.pow(arg0, arg1); //arg0 is the         , arg1 is the 

		/* Other Java Math Methods (p. 43)
		 * http://www.coursesmart.com/bookshelf
		 * 
		 * API Documentation (syntax and use of library functions) - search for Java Oracle Documentation
		 * 						or use http://docs.oracle.com/javase/8/docs/api/
		 */
		// Examples using math methods
		//exponent example: 2 ^ 5
		
		//square root of 16
		
		// Compound Interest
		
		// Quadratic formula
		
		/*
		 * Converting floating point to integers
		 * Implicit cast - 
		 * Explicit cast -
		 *    see pages 44 & 45
		 */
		// Examples of conversions
		//truncating decimal part
		
		//convert result of math expression to int
		
		// round (returns          )
		
		// round - forced to int type
		
		/*
		 * Combining assignment statement with arithmetic
		 *  i.e. Total += cans; means
		 *  i.e. Total *= 2 means
		 *  use spacing to help legibility!
		 */
		
		/*
		 * Counting parentheses
		 *   Debug this statement:
		 *   Total = (a+b)*t)(2*(1-t)
		 */

	}

}
