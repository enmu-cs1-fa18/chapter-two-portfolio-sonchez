

public class ClassSec4 {

	public static void main(String[] args) {
		// Input/Process/Output and Problem Solving
/*
 * Look at code on page 56 of text book. This is an example of GOOD code. We can 
 * learn a lot from GOOD code by analyzing how the programmer wrote his/her code.
 * 
 * What do you notice about the layout of the code?
 * Where are the declarations for the constants?
 * Where is the input from the user?
 * Where are the calculations done?
 * Where are the outputs done?
 * Where are comments made?
 * Where are the variable declarations done?
 * How was code chunked?
 * 
 * 
 */
	}

}
